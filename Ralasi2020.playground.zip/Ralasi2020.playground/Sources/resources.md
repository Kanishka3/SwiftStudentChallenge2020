
Winning sound:  https://freesound.org/people/scratchers/sounds/505717/

Stigma Love: https://keystonehealth.org/wp-content/uploads/2018/05/green-ribbon-in-frame.png

Apple Winning Sound: 
